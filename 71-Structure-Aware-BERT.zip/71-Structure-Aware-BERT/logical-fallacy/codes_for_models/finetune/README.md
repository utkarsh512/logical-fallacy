Code changed from https://github.com/huggingface/transformers/tree/master/examples/legacy/seq2seq

## Requirements

pytorch 1.7.1
transformers 4.10

## How to Run
train the model:
```bash
python main.py train.json
```

output the probability:
```bash
python main.py test.json
```

## Parameters
train.json
```
{
"tokenizer_name": "../../results/fallacy/deberta/best-epoch",
"model_name": "../../results/fallacy/deberta/best-epoch",
"freeze_encoder": false, # optional, we set to false
"freeze_embeds": false, # optional, we set to false
"data_dir": "../../datasets/fallacy/sentence/",
"max_source_length": 128,
"task_type": "sequence_matching",
"mode": "train", # file name
"test_type": "dev",

"num_labels":3, # NLI's 0,1,2
"output_dir": "../../results/fallacy/propa/deberta", # save checkpoints to this
"do_train": true,
"evaluation_strategy": "steps", # evaluate by every X steps
"overwrite_output_dir": true,
"per_device_train_batch_size": 8,
"per_device_eval_batch_size": 128,
"eval_steps": 300,
"save_total_limit": 1, # how many checkpoints to save
"load_best_model_at_end": true,
"logging_steps": 300,
"fp16": false,
"gradient_accumulation_steps": 2,
"save_steps": 30000000000,  # we don't need to save intermediate steps, so we set it to a super large number
"logging_dir": "../../results/fallacy/propa/logs",
"num_train_epochs": 5, # we didn't tune this, just set 5 for all models
"seed": 42, # we set a random seed
"warmup_steps": 1931,
"learning_rate": 1e-05
}
```

test.json
```
{
"tokenizer_name": "../../results/fallacy/finetuned/roberta/best-epoch",
"model_name": "../../results/fallacy/finetuned/roberta/best-epoch",
"data_dir": "../../datasets/fallacy/article/",
"max_source_length": 512, # bigbird 4096
"task_type": "sequence_matching", # always set to this
"mode": "output_prob",

"num_labels":3,
"test_type": "test", # file name
"output_dir": "../../results/fallacy/finetuned/roberta", # save probs to a txt file of probs
"per_device_eval_batch_size": 64,
"fp16": false # mobilebert does not support this
}
```