### Environment
```bash
pip install efficiency
```

### How to Run
```bash
cd ../
python zeroshot/model1_transfer_from_nli.py
```